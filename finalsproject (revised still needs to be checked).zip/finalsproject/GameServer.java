import java.io.*;
import java.net.*;

public class GameServer {
    private ServerSocket serverSocket;
    private int numPlayers = 0;

    public GameServer() {
        try {
            serverSocket = new ServerSocket(2405);
            System.out.println("Game Server Online...");
        } catch (IOException e) { e.printStackTrace(); }
    }

    public void acceptConnections() {
        try {
            while (numPlayers < 2) {
                Socket s = serverSocket.accept();
                numPlayers++;
                ServerSideConnection ssc = new ServerSideConnection(s, numPlayers);
                new Thread(ssc).start();
            }
        } catch (IOException e) { e.printStackTrace(); }
    }

    private class ServerSideConnection implements Runnable {
        private Socket socket;
        private DataInputStream dataIn;
        private DataOutputStream dataOut;
        private int playerID;

        public ServerSideConnection(Socket s, int id) {
            this.socket = s; // This clears the "socket is not used" warning
            this.playerID = id;
            try {
                dataIn = new DataInputStream(socket.getInputStream());
                dataOut = new DataOutputStream(socket.getOutputStream());
            } catch (IOException e) { e.printStackTrace(); }
        }

        public void run() {
            try {
                dataOut.writeInt(playerID);
                while (true) {
                    // Actively reading the data sent by the player
                    int px = dataIn.readInt();
                    int py = dataIn.readInt();
                }
            } catch (IOException e) { System.out.println("Player left."); }
        }
    }

    public static void main(String[] args) {
        new GameServer().acceptConnections();
    }
}