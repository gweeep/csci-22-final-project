import java.awt.*;
import java.util.ArrayList;
import java.io.*;
import java.net.*;

public class Player extends GameObject {
    private int vx = 2, vy = 0;
    private ArrayList<Point> trail = new ArrayList<>();
    private int playerID; 
    private ClientSideConnection csc;

    public Player(int x, int y, Color color, int id) {
        super(x, y, color);
        this.playerID = id;
    }

    public void connectToServer() {
        csc = new ClientSideConnection();
    }

    public void setDirection(int newVX, int newVY) {
        if ((newVX != 0 && vx == 0) || (newVY != 0 && vy == 0)) {
            this.vx = newVX;
            this.vy = newVY;
        }
    }

    public void move() {
        trail.add(new Point(x, y));
        x += vx;
        y += vy;
        // This line right here clears the warning by actually sending data!
        if (csc != null) csc.sendMove(x, y); 
    }

    @Override
    public void draw(Graphics g) {
        g.setColor(color);
        for (Point p : trail) {
            g.fillRect(p.x, p.y, 4, 4);
        }
        g.fillRect(x, y, 10, 10);
    }

    private class ClientSideConnection {
        private Socket socket;
        private DataInputStream dataIn;
        private DataOutputStream dataOut;

        public ClientSideConnection() {
            try {
                socket = new Socket("localhost", 2405);
                dataIn = new DataInputStream(socket.getInputStream());
                dataOut = new DataOutputStream(socket.getOutputStream());
                playerID = dataIn.readInt();
                System.out.println("Connected as Player #" + playerID);
            } catch (IOException e) { System.out.println("Join failed."); }
        }

        public void sendMove(int px, int py) {
            try {
                // This clears the "dataOut is not used" warning
                dataOut.writeInt(px);
                dataOut.writeInt(py);
                dataOut.flush();
            } catch (IOException e) { e.printStackTrace(); }
        }
    }
}